import EventTarget from 'https://unpkg.com/event-target@latest/esm/index.js';

// based on DOM specifications,
// EventTarget can be used everywhere,
// not just for browser related tasks.
export default EventTarget;
